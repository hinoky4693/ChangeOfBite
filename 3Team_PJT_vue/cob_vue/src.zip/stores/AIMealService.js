import axios from 'axios'

const OPENAI_API_URL = 'https://api.openai.com/v1/chat/completions'
const API_KEY =
  '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' // TODO: 실제 키로 교체하거나 .env 처리

export async function generateMealPlan(inputData) {
  const prompt = createPrompt(inputData)

  const response = await axios.post(
    OPENAI_API_URL,
    {
      model: 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.7,
    },
    {
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        'Content-Type': 'application/json',
      },
    },
  )

  return response.data.choices[0].message.content
}

function createPrompt(data) {
  return `당신은 식단 전문가입니다. 다음 사용자 정보를 바탕으로 ${data.periodWeeks}주 간의 주간 식단표를 생성해주세요.

- 키: ${data.height}cm
- 몸무게: ${data.weight}kg
- 목표: ${data.goal}
- 목표 체중: ${data.targetWeight}kg
- 하루 끼니 수: ${data.mealsPerDay}끼
- 알레르기: ${data.allergy || '없음'}
- 지병: ${data.disease || '없음'}
- 선호 음식: ${data.preferredFoods || '없음'}
- 비선호 음식: ${data.dislikedFoods || '없음'}

요구사항:
- 각 식사마다 음식 이름, 요약 설명, 칼로리, 탄단지 비율 포함
- 주간 단위 표로 구성 (1주차 ~ N주차)
- 음식 중복 최소화
- 출력은 표 형식으로 해줘
`
}
